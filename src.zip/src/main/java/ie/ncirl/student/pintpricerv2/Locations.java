package ie.ncirl.student.pintpricerv2;

public class Locations {
    // private String selector = SelectionActivity2.drinkSpinner1;
    private String title;
    private String description;
    private double price;
   // private double tiger;
   // private double carlsberg;
   // private double fosters;


    public Locations(String title, String description, double price){
        this.title = title;
        this.description = description;
        this.price = price;
      //  this.tiger = tiger;
      //  this.carlsberg = carlsberg;
      //  this.fosters = fosters;
    }

    public Locations(){
        //empty constructor needed
    }


  //  public double getTiger() {
 //       return tiger;
 //   }

 //   public void setTiger(double tiger) {
 //       this.tiger = tiger;
 //   }

 //   public double getCarlsberg() {
 //       return carlsberg;
 //   }

//    public void setCarlsberg(double carlsberg) {
 //       this.carlsberg = carlsberg;
 //   }

//    public double getFosters() {
 //       return fosters;
 //   }

  //  public void setFosters(double fosters) {
  //      this.fosters = fosters;
  //  }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
